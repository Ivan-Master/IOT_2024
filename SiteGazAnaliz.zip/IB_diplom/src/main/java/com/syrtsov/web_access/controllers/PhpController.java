package com.kofanov.web_access.controllers;


import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@Controller
//@RequestMapping(value={"/sensors", "/journal"})
@PreAuthorize("hasAuthority('USER2')")
public class PhpController {


    @GetMapping("/redirectGraph")
    public String redirectBME() {
        return "redirect:http://localhost/dipib/Send_graph_DB.php";
    }

}
