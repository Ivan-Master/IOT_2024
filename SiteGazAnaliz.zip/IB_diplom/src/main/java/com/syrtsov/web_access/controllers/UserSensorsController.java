package com.kofanov.web_access.controllers;

import com.kofanov.web_access.domain.entity.Journal;
import com.kofanov.web_access.domain.service.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Controller
//@RequestMapping(value={"/sensors", "/journal"})
@PreAuthorize("hasAuthority('USER2')")
public class UserSensorsController {



    @Autowired
    private DataService dataService;

    @GetMapping("/sensors")
    public String getData(Model model) {
        // Путь к файлу в папке src
        String filePath = "src/OneData.txt";

        // Чтение строки из файла
        String dataString = null;
        try {
            dataString = Files.readString(Paths.get(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }


        // Извлечение значений температуры, влажности, давления, сопротивления газа и даты/времени
        Pattern pattern = Pattern.compile("T([0-9]+)H([0-9]+)P([0-9]+)GR([0-9]+)S([0-9]+)[\t ]+(.*)");
        Matcher matcher = pattern.matcher(dataString);
        if (matcher.find()) {

            int temperature = Integer.parseInt(matcher.group(1));
            int humidity = Integer.parseInt(matcher.group(2));
            int pressure = Integer.parseInt(matcher.group(3));
            int gasResistance = Integer.parseInt(matcher.group(4));
            int smoke = Integer.parseInt(matcher.group(5));
            String dateTime = matcher.group(6);
            dateTime = dateTime.substring(0,19);
            model.addAttribute("temperature", temperature);
            model.addAttribute("humidity", humidity);
            model.addAttribute("pressure", pressure);
            model.addAttribute("gasResistance", gasResistance);
            model.addAttribute("smoke", smoke);
            model.addAttribute("dateTime", dateTime);

            if(smoke < 1000)
            {
                String gazik = "/static/PhotoForMain/kitchen_up.jpg";
                model.addAttribute("kitchen", gazik);
            }
            else
            {
                String gazik = "/static/PhotoForMain/kitchen_black_smoke_fig.gif";
                model.addAttribute("kitchen", gazik);
            }


        } else {
            System.out.println("Строка данных не соответствует ожидаемому формату.");
        }


        // Добавление данных в модель

        // Возвращение представления
        return "sensors";
    }
    @GetMapping("/journal")
    public String journal(Model model) {
        List<Journal> records = dataService.getLatestRecords();
        model.addAttribute("records", records);
        return "journal";
    }
}
