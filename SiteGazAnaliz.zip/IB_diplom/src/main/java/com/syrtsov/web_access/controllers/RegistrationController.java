package com.kofanov.web_access.controllers;

import com.kofanov.web_access.configы.XssSanitizer;
import com.kofanov.web_access.domain.entity.Role;
import com.kofanov.web_access.domain.entity.Secret;
import com.kofanov.web_access.domain.entity.User;
import com.kofanov.web_access.domain.repo.SecretRepo;
import com.kofanov.web_access.domain.repo.UserRepo;
import com.kofanov.web_access.domain.service.SecretService;
import com.kofanov.web_access.domain.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;

@Controller
public class RegistrationController {
    @Autowired
    private UserRepo userRepo;

    @Autowired
    private SecretRepo secretRepo;
    @Autowired
    private UserService userService;
    @Autowired
    private SecretService secretService;

    @Autowired
    private PasswordEncoder passwordEncoder;


    @GetMapping("/registration")
    public String registration(){
        return "registration";
    }

    @PostMapping("/registration")
    public String addUser(@Validated User user, BindingResult bindingResult, @RequestParam String secret, Model model){
        // Валидация данных пользователя
        if (bindingResult.hasErrors()) {
            return "registration";
        }
        // Санитизация входных данных
        user.setUsername(XssSanitizer.sanitize(user.getUsername()));
        user.setPassword(XssSanitizer.sanitize(user.getPassword()));

        User userFromDB = userRepo.findByUsername( user.getUsername() );

        if (userFromDB != null){
            //model.addAttribute( "message", "Пользователь уже существует!" );
            return "registration";
        }

        if (secretService.checkSecretExists(secret)) {
            user.setActive( true );
            if(secret.equals("1001")){
                user.setRoles( Collections.singleton( Role.USER1 ) );
            } else if (secret.equals("1002")) {
                user.setRoles( Collections.singleton( Role.USER2 ) );
            } else if (secret.equals("1003")) {
                user.setRoles( Collections.singleton( Role.ADMIN ) );
            }

            userService.saveUser( user );
            return "redirect:/login";
        } else if (!secretService.checkSecretExists(secret)){
            return "redirect:/";
        }

//        if (userFromDB != null){
//            model.addAttribute( "message", "Пользователь уже существует!" );
//            return "registration";
//        }
//        user.setActive( true );
//        user.setRoles( Collections.singleton( Role.ADMIN ) );
//        userRepo.save( user );
        //model.addAttribute("error", "Invalid secret value");
        return "redirect:/login";
    }
}
//INSERT INTO `secret`(`secret`) VALUES ('1001'),('1002')