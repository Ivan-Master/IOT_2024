package com.kofanov.web_access.domain.repo;

import com.kofanov.web_access.domain.entity.Secret;
import com.kofanov.web_access.domain.entity.User;
import org.springframework.data.repository.CrudRepository;

public interface UserRepo extends CrudRepository<User, Long>{
    User findByUsername(String username);


}
